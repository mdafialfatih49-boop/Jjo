# Block Fusion v2 (Fabric 1.20.1)
Susunan: [piston] [isi1] [isi2] [piston] saling berhadapan + lever. Tekan lever -> isi1 dan isi2 menyatu.

BLOCK: block kubus penuh -> block gabungan (texture mozaik, sifat otomatis). Block sama = Super X. Piston+piston = Super Piston.
ITEM : jatuhkan 2 item di celah (di antara dua piston, tanpa block) lalu tekan lever.
  - air bucket + susu bucket = Milk Fluid Bucket (fluida susu, bisa diletakkan) + 1 bucket kosong
  - block item + block item = block gabungan
  - item lain = Item Gabungan (serangan dijumlah, kecepatan menambang terbaik, makanan digabung)
Build: GitHub Actions workflow, ambil jar dari Artifacts. Jika crash, kirim isi logs/latest.log.
