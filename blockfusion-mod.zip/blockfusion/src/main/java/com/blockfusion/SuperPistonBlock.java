package com.blockfusion;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.FacingBlock;
import net.minecraft.block.MapColor;
import net.minecraft.block.PistonBlock;
import net.minecraft.block.piston.PistonBehavior;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class SuperPistonBlock extends PistonBlock {
    private final boolean stickyType;

    public SuperPistonBlock(boolean sticky) {
        super(sticky, settings());
        this.stickyType = sticky;
    }

    public boolean isStickyType() { return stickyType; }

    private static AbstractBlock.Settings settings() {
        AbstractBlock.ContextPredicate notExtended = (s, w, p) -> !s.get(PistonBlock.EXTENDED);
        return AbstractBlock.Settings.create().mapColor(MapColor.GOLD).strength(2.5f)
                .solidBlock((s, w, p) -> false).suffocates(notExtended).blockVision(notExtended)
                .pistonBehavior(PistonBehavior.BLOCK);
    }

    @Override
    public boolean onSyncedBlockEvent(BlockState state, World world, BlockPos pos, int type, int data) {
        boolean ok = super.onSyncedBlockEvent(state, world, pos, type, data);
        if (ok && type == 0 && !world.isClient) {
            Direction d = state.get(FacingBlock.FACING);
            Box box = new Box(pos.offset(d)).union(new Box(pos.offset(d, 3)));
            Vec3d push = Vec3d.of(d.getVector()).multiply(2.2).add(0, 0.45, 0);
            for (LivingEntity e : world.getEntitiesByClass(LivingEntity.class, box, x -> true)) {
                e.setVelocity(push);
                e.velocityModified = true;
                e.fallDistance = 0;
            }
        }
        return ok;
    }
}
