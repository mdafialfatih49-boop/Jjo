package com.blockfusion;

import net.minecraft.block.*;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.EmptyBlockView;
import java.util.List;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

public final class FusionHandler {
    private FusionHandler() {}

    private static boolean isPiston(BlockState s) {
        return s.getBlock() instanceof PistonBlock && !s.get(PistonBlock.EXTENDED);
    }

    private static boolean fusable(ServerWorld w, BlockPos p, BlockState s) {
        if (s.isAir() || s.hasBlockEntity() || s.getBlock() instanceof FusedBlock || s.getBlock() instanceof PistonBlock) return false;
        if (!s.getFluidState().isEmpty()) return false;
        if (s.isOf(Blocks.HONEY_BLOCK) || s.isOf(Blocks.CACTUS)) return true;
        if (s.getRenderType() != BlockRenderType.MODEL) return false;
        return Block.isShapeFullCube(s.getCollisionShape(w, p)) || Block.isShapeFullCube(s.getOutlineShape(w, p));
    }

    /**
     * Pola: [piston ini] [blok1] [blok2] [piston lawan]. Dipanggil saat piston ini hendak memanjang.
     * @return true jika terjadi fusi (piston tidak perlu memanjang)
     */
    public static boolean tryFuse(ServerWorld w, BlockPos pistonPos, BlockState pistonState, Direction d) {
        BlockPos p1 = pistonPos.offset(d), p2 = p1.offset(d), p3 = p2.offset(d);
        BlockState s1 = w.getBlockState(p1), s2 = w.getBlockState(p2), s3 = w.getBlockState(p3);
        if (!(s3.getBlock() instanceof PistonBlock) || s3.get(FacingBlock.FACING) != d.getOpposite() || s3.get(PistonBlock.EXTENDED)) return false;

        // piston + piston = super piston
        if (isPiston(s1) && isPiston(s2)) {
            boolean sticky = isSticky(s1) || isSticky(s2);
            Block sp = sticky ? ModContent.SUPER_STICKY_PISTON : ModContent.SUPER_PISTON;
            BlockState result = sp.getDefaultState().with(FacingBlock.FACING, s1.get(FacingBlock.FACING)).with(PistonBlock.EXTENDED, false);
            w.setBlockState(p2, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL);
            w.setBlockState(p1, result, Block.NOTIFY_ALL);
            effects(w, p1);
            return true;
        }

        if (!fusable(w, p1, s1) || !fusable(w, p2, s2)) {
            return tryFuseItems(w, p1, p2, s1, s2);
        }

        w.setBlockState(p2, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL);
        w.setBlockState(p1, ModContent.FUSED_BLOCK.getDefaultState(), Block.NOTIFY_ALL);
        if (w.getBlockEntity(p1) instanceof FusedBlockEntity f) {
            f.set(s1.getBlock(), s2.getBlock());
            FusedBlock.refresh(w, p1);
        }
        effects(w, p1);
        return true;
    }

    public static boolean fusableBlock(Block b) {
        BlockState s = b.getDefaultState();
        if (b instanceof FusedBlock || b instanceof PistonBlock || s.isAir() || s.hasBlockEntity() || !s.getFluidState().isEmpty()) return false;
        if (s.isOf(Blocks.HONEY_BLOCK) || s.isOf(Blocks.CACTUS)) return true;
        if (s.getRenderType() != BlockRenderType.MODEL) return false;
        return Block.isShapeFullCube(s.getOutlineShape(EmptyBlockView.INSTANCE, BlockPos.ORIGIN));
    }

    /** Dua item yang dijatuhkan di celah antara dua piston digabung. */
    private static boolean tryFuseItems(ServerWorld w, BlockPos p1, BlockPos p2, BlockState s1, BlockState s2) {
        if (!s1.getCollisionShape(w, p1).isEmpty() || !s2.getCollisionShape(w, p2).isEmpty()) return false;
        Box box = new Box(p1).union(new Box(p2));
        List<ItemEntity> items = w.getEntitiesByClass(ItemEntity.class, box, e -> e.isAlive() && !e.getStack().isEmpty());
        if (items.isEmpty()) return false;
        ItemEntity e1 = items.get(0);
        ItemEntity e2 = items.size() > 1 ? items.get(1) : e1;
        if (e1 == e2 && e1.getStack().getCount() < 2) return false;
        ItemStack a = e1.getStack().copy(); a.setCount(1);
        ItemStack b = e2.getStack().copy(); b.setCount(1);
        ItemStack[] r = ItemFusion.fuse(a, b);
        if (r == null) return false;
        if (e1 == e2) take(e1, 2); else { take(e1, 1); take(e2, 1); }
        Vec3d c = p1.toCenterPos().add(p2.toCenterPos()).multiply(0.5);
        for (ItemStack st : r) {
            if (st.isEmpty()) continue;
            ItemEntity out = new ItemEntity(w, c.x, c.y, c.z, st);
            out.setVelocity(0, 0.15, 0);
            w.spawnEntity(out);
        }
        effects(w, p1);
        return true;
    }

    private static void take(ItemEntity e, int n) {
        ItemStack s = e.getStack().copy();
        s.decrement(n);
        if (s.isEmpty()) e.discard(); else e.setStack(s);
    }

    private static boolean isSticky(BlockState s) {
        Block b = s.getBlock();
        if (b instanceof SuperPistonBlock sp) return sp.isStickyType();
        return b == Blocks.STICKY_PISTON;
    }

    private static void effects(ServerWorld w, BlockPos p) {
        w.playSound(null, p, SoundEvents.BLOCK_BEACON_ACTIVATE, SoundCategory.BLOCKS, 1f, 1.4f);
        w.spawnParticles(ParticleTypes.END_ROD, p.getX() + .5, p.getY() + .5, p.getZ() + .5, 30, .4, .4, .4, 0.05);
    }
}
