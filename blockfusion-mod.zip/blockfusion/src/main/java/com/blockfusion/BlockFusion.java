package com.blockfusion;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;

public class BlockFusion implements ModInitializer {
    public static final String ID = "blockfusion";

    @Override
    public void onInitialize() {
        ModContent.init();
        ModFluids.init();
        // Block hasil gabungan yang mengandung bedrock tidak bisa dihancurkan (termasuk di creative)
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, be) ->
                !(be instanceof FusedBlockEntity f && f.hardness(world, pos) < 0));
    }
}
