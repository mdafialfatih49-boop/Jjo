package com.blockfusion.client;

import com.blockfusion.FusedBlockItem;
import com.blockfusion.ModContent;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandlerRegistry;
import net.fabricmc.fabric.api.client.render.fluid.v1.SimpleFluidRenderHandler;
import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import com.blockfusion.FusedItem;
import com.blockfusion.ModFluids;
import net.minecraft.client.render.block.entity.BlockEntityRendererFactories;

public class BlockFusionClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        BlockEntityRendererFactories.register(ModContent.FUSED_BE, ctx -> new FusedBlockEntityRenderer());
        BuiltinItemRendererRegistry.INSTANCE.register(ModContent.FUSED_BLOCK_ITEM,
                (stack, mode, matrices, vcp, light, overlay) -> {
                    Block[] bs = FusedBlockItem.blocksOf(stack);
                    FusedBlockEntityRenderer.renderMosaic(bs[0], bs[1], matrices, vcp, light, overlay);
                });
        BuiltinItemRendererRegistry.INSTANCE.register(ModContent.FUSED_ITEM,
                (stack, mode, matrices, vcp, light, overlay) -> {
                    ItemStack[] s = FusedItem.stacksOf(stack);
                    float[][] off = {{-0.14f, 0.14f}, {0.14f, -0.14f}};
                    for (int i = 0; i < 2; i++) {
                        if (s[i].isEmpty()) continue;
                        matrices.push();
                        matrices.translate(0.5 + off[i][0], 0.5 + off[i][1], 0.5);
                        matrices.scale(0.72f, 0.72f, 0.72f);
                        MinecraftClient.getInstance().getItemRenderer().renderItem(s[i], mode, light, overlay, matrices, vcp, null, 0);
                        matrices.pop();
                    }
                });
        FluidRenderHandlerRegistry.INSTANCE.register(ModFluids.STILL, ModFluids.FLOWING,
                new SimpleFluidRenderHandler(new Identifier("blockfusion:block/milk_still"), new Identifier("blockfusion:block/milk_flow"), 0xFFFFFF));
        BlockRenderLayerMap.INSTANCE.putFluids(RenderLayer.getTranslucent(), ModFluids.STILL, ModFluids.FLOWING);
    }
}
