package com.blockfusion.client;

import com.blockfusion.FusedBlockEntity;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.BlockRenderManager;
import net.minecraft.client.render.block.entity.BlockEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;

/** Texture gabungan: block dipecah jadi 8 kubus kecil berselang-seling (mozaik) dari tekstur kedua block. */
public class FusedBlockEntityRenderer implements BlockEntityRenderer<FusedBlockEntity> {
    @Override
    public void render(FusedBlockEntity be, float tickDelta, MatrixStack matrices, VertexConsumerProvider vcp, int light, int overlay) {
        renderMosaic(be.getA(), be.getB(), matrices, vcp, light, overlay);
    }

    public static void renderMosaic(Block a, Block b, MatrixStack m, VertexConsumerProvider vcp, int light, int overlay) {
        BlockRenderManager brm = MinecraftClient.getInstance().getBlockRenderManager();
        BlockState sa = a.getDefaultState(), sb = b.getDefaultState();
        for (int x = 0; x < 2; x++) for (int y = 0; y < 2; y++) for (int z = 0; z < 2; z++) {
            m.push();
            m.translate(x * 0.5, y * 0.5, z * 0.5);
            m.scale(0.5f, 0.5f, 0.5f);
            brm.renderBlockAsEntity(((x + y + z) & 1) == 0 ? sa : sb, m, vcp, light, overlay);
            m.pop();
        }
    }
}
