package com.blockfusion.mixin;

import com.blockfusion.SuperPistonBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.FacingBlock;
import net.minecraft.block.PistonBlock;
import net.minecraft.block.PistonHeadBlock;
import net.minecraft.block.enums.PistonType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PistonHeadBlock.class)
public abstract class PistonHeadBlockMixin {
    /** Kepala piston vanilla harus mengenali super piston sebagai pangkalnya. */
    @Inject(method = "isAttached", at = @At("HEAD"), cancellable = true)
    private void blockfusion$attached(BlockState head, BlockState base, CallbackInfoReturnable<Boolean> cir) {
        if (base.getBlock() instanceof SuperPistonBlock sp
                && base.get(PistonBlock.EXTENDED)
                && base.get(FacingBlock.FACING) == head.get(FacingBlock.FACING)
                && sp.isStickyType() == (head.get(PistonHeadBlock.TYPE) == PistonType.STICKY)) {
            cir.setReturnValue(true);
        }
    }
}
