package com.blockfusion.mixin;

import com.blockfusion.FusionHandler;
import com.blockfusion.SuperPistonBlock;
import net.minecraft.block.*;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PistonBlock.class)
public abstract class PistonBlockMixin {
    @Shadow protected abstract boolean shouldExtend(World world, BlockPos pos, Direction pistonFace);

    @Inject(method = "tryMove", at = @At("HEAD"), cancellable = true)
    private void blockfusion$tryMove(World world, BlockPos pos, BlockState state, CallbackInfo ci) {
        com.blockfusion.PistonFlags.SUPER.set((Object) this instanceof SuperPistonBlock);
        if (world.isClient) return;
        Direction dir = state.get(FacingBlock.FACING);
        if (!state.get(PistonBlock.EXTENDED) && this.shouldExtend(world, pos, dir)) {
            if (FusionHandler.tryFuse((ServerWorld) world, pos, state, dir)) {
                com.blockfusion.PistonFlags.SUPER.set(false);
                ci.cancel();
            }
        }
    }

    @Inject(method = "tryMove", at = @At("RETURN"))
    private void blockfusion$tryMoveEnd(World world, BlockPos pos, BlockState state, CallbackInfo ci) {
        com.blockfusion.PistonFlags.SUPER.set(false);
    }

    @Inject(method = "move", at = @At("HEAD"))
    private void blockfusion$moveStart(World world, BlockPos pos, Direction dir, boolean retract, CallbackInfoReturnable<Boolean> cir) {
        com.blockfusion.PistonFlags.SUPER.set((Object) this instanceof SuperPistonBlock);
    }

    @Inject(method = "move", at = @At("RETURN"))
    private void blockfusion$moveEnd(World world, BlockPos pos, Direction dir, boolean retract, CallbackInfoReturnable<Boolean> cir) {
        com.blockfusion.PistonFlags.SUPER.set(false);
    }

    /** Super piston bisa mendorong bedrock dan obsidian. */
    @Inject(method = "isMovable", at = @At("HEAD"), cancellable = true)
    private static void blockfusion$isMovable(BlockState state, World world, BlockPos pos, Direction direction, boolean canBreak, Direction pistonDir, CallbackInfoReturnable<Boolean> cir) {
        if (!com.blockfusion.PistonFlags.SUPER.get()) return;
        if (!(state.isOf(Blocks.BEDROCK) || state.isOf(Blocks.OBSIDIAN) || state.isOf(Blocks.CRYING_OBSIDIAN))) return;
        int y = pos.getY();
        boolean ok = y >= world.getBottomY() && y <= world.getTopY() - 1 && world.getWorldBorder().contains(pos);
        if (direction == Direction.DOWN && y == world.getBottomY()) ok = false;
        if (direction == Direction.UP && y == world.getTopY() - 1) ok = false;
        cir.setReturnValue(ok);
    }
}
