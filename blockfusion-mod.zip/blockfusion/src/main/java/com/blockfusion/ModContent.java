package com.blockfusion;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.block.*;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.block.piston.PistonBehavior;
import net.minecraft.item.*;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public final class ModContent {
    public static Identifier id(String p) { return new Identifier(BlockFusion.ID, p); }

    public static final FusedBlock FUSED_BLOCK = Registry.register(Registries.BLOCK, id("fused_block"),
            new FusedBlock(AbstractBlock.Settings.create().mapColor(MapColor.STONE_GRAY).strength(3.0f, 6.0f)
                    .nonOpaque().suffocates((s, w, p) -> true).blockVision((s, w, p) -> false)
                    .luminance(s -> s.get(FusedBlock.LIGHT))));
    public static final Item FUSED_BLOCK_ITEM = Registry.register(Registries.ITEM, id("fused_block"),
            new FusedBlockItem(FUSED_BLOCK, new Item.Settings()));
    public static final BlockEntityType<FusedBlockEntity> FUSED_BE = Registry.register(Registries.BLOCK_ENTITY_TYPE,
            id("fused_block"), BlockEntityType.Builder.create(FusedBlockEntity::new, FUSED_BLOCK).build(null));

    public static final Item FUSED_ITEM = Registry.register(Registries.ITEM, id("fused_item"), new FusedItem(new Item.Settings()));

    public static final SuperPistonBlock SUPER_PISTON = Registry.register(Registries.BLOCK, id("super_piston"), new SuperPistonBlock(false));
    public static final SuperPistonBlock SUPER_STICKY_PISTON = Registry.register(Registries.BLOCK, id("super_sticky_piston"), new SuperPistonBlock(true));
    public static final Item SUPER_PISTON_ITEM = Registry.register(Registries.ITEM, id("super_piston"), new BlockItem(SUPER_PISTON, new Item.Settings()));
    public static final Item SUPER_STICKY_PISTON_ITEM = Registry.register(Registries.ITEM, id("super_sticky_piston"), new BlockItem(SUPER_STICKY_PISTON, new Item.Settings()));

    public static final ItemGroup GROUP = Registry.register(Registries.ITEM_GROUP, id("main"),
            FabricItemGroup.builder().displayName(Text.translatable("itemGroup.blockfusion"))
                    .icon(() -> FusedBlockItem.stackOf(Blocks.HAY_BLOCK, Blocks.GRASS_BLOCK))
                    .entries((ctx, e) -> {
                        e.add(ModFluids.BUCKET);
                        e.add(FusedItem.stackOf(new ItemStack(Items.DIAMOND_SWORD), new ItemStack(Items.IRON_AXE)));
                        e.add(FusedItem.stackOf(new ItemStack(Items.DIAMOND_PICKAXE), new ItemStack(Items.DIAMOND_SHOVEL)));
                        e.add(FusedItem.stackOf(new ItemStack(Items.GOLDEN_APPLE), new ItemStack(Items.COOKED_BEEF)));
                        e.add(SUPER_PISTON_ITEM);
                        e.add(SUPER_STICKY_PISTON_ITEM);
                        e.add(FusedBlockItem.stackOf(Blocks.NETHERITE_BLOCK, Blocks.NETHERITE_BLOCK));
                        e.add(FusedBlockItem.stackOf(Blocks.HAY_BLOCK, Blocks.GRASS_BLOCK));
                        e.add(FusedBlockItem.stackOf(Blocks.TNT, Blocks.OBSIDIAN));
                        e.add(FusedBlockItem.stackOf(Blocks.TNT, Blocks.SAND));
                        e.add(FusedBlockItem.stackOf(Blocks.TNT, Blocks.TNT));
                        e.add(FusedBlockItem.stackOf(Blocks.BEDROCK, Blocks.NETHERITE_BLOCK));
                        e.add(FusedBlockItem.stackOf(Blocks.SLIME_BLOCK, Blocks.HAY_BLOCK));
                        e.add(FusedBlockItem.stackOf(Blocks.GLOWSTONE, Blocks.REDSTONE_BLOCK));
                        e.add(FusedBlockItem.stackOf(Blocks.MAGMA_BLOCK, Blocks.CACTUS));
                        e.add(FusedBlockItem.stackOf(Blocks.HONEY_BLOCK, Blocks.SOUL_SAND));
                    }).build());

    public static void init() {}
}
