package com.blockfusion;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class FusedBlockItem extends BlockItem {
    public FusedBlockItem(Block block, Settings settings) { super(block, settings); }

    public static ItemStack stackOf(Block a, Block b) {
        ItemStack s = new ItemStack(ModContent.FUSED_BLOCK_ITEM);
        NbtCompound t = s.getOrCreateSubNbt("BlockEntityTag");
        t.putString("a", Registries.BLOCK.getId(a).toString());
        t.putString("b", Registries.BLOCK.getId(b).toString());
        return s;
    }

    public static Block[] blocksOf(ItemStack stack) {
        NbtCompound t = stack.getSubNbt("BlockEntityTag");
        if (t == null || !t.contains("a") || !t.contains("b")) return new Block[]{Blocks.STONE, Blocks.STONE};
        return new Block[]{parse(t.getString("a")), parse(t.getString("b"))};
    }

    private static Block parse(String s) {
        Identifier id = Identifier.tryParse(s);
        if (id == null) return Blocks.STONE;
        Block b = Registries.BLOCK.get(id);
        return b == Blocks.AIR ? Blocks.STONE : b;
    }

    @Override
    public Text getName(ItemStack stack) {
        if (stack.getSubNbt("BlockEntityTag") == null) return super.getName(stack);
        Block[] bs = blocksOf(stack);
        if (bs[0] == bs[1]) return Text.translatable("block.blockfusion.fused_super", bs[0].getName());
        return Text.translatable("block.blockfusion.fused", bs[0].getName(), bs[1].getName());
    }
}
