package com.blockfusion;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.BlockEntityUpdateS2CPacket;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockView;

public class FusedBlockEntity extends BlockEntity {
    private Block a = Blocks.STONE;
    private Block b = Blocks.STONE;

    public FusedBlockEntity(BlockPos pos, BlockState state) {
        super(ModContent.FUSED_BE, pos, state);
    }

    public Block getA() { return a; }
    public Block getB() { return b; }
    public void set(Block a, Block b) { this.a = a; this.b = b; markDirty(); }
    public boolean isSuper() { return a == b; }

    public boolean has(Block... blocks) {
        for (Block x : blocks) if (a == x || b == x) return true;
        return false;
    }

    // ---- sifat otomatis dari kedua block ----
    public int light() { return Math.max(a.getDefaultState().getLuminance(), b.getDefaultState().getLuminance()); }
    public boolean redstone() { return has(Blocks.REDSTONE_BLOCK); }
    public boolean explosive() { return has(Blocks.TNT); }
    public boolean bouncy() { return has(Blocks.SLIME_BLOCK); }
    public boolean cushion() { return has(Blocks.HAY_BLOCK); }
    public boolean slows() { return has(Blocks.HONEY_BLOCK, Blocks.SOUL_SAND); }
    public boolean hurts() { return has(Blocks.CACTUS, Blocks.MAGMA_BLOCK); }

    public float hardness(BlockView world, BlockPos pos) {
        float ha = a.getDefaultState().getHardness(world, pos);
        float hb = b.getDefaultState().getHardness(world, pos);
        if (ha < 0 || hb < 0) return -1f;
        float h = (ha + hb) / 2f;
        if (isSuper()) h *= 1.5f;
        return Math.max(h, 0.3f);
    }

    /** Block yang dipakai untuk mengubah area sekitar saat TNT gabungan meledak (null jika tidak ada). */
    public Block transformBlock() {
        if (a == Blocks.TNT && b == Blocks.TNT) return null;
        if (a == Blocks.TNT) return b;
        if (b == Blocks.TNT) return a;
        return null;
    }

    private static Block read(NbtCompound nbt, String key) {
        Identifier id = Identifier.tryParse(nbt.getString(key));
        if (id == null) return Blocks.STONE;
        Block blk = Registries.BLOCK.get(id);
        return blk == Blocks.AIR ? Blocks.STONE : blk;
    }

    @Override
    public void readNbt(NbtCompound nbt) {
        super.readNbt(nbt);
        if (nbt.contains("a")) a = read(nbt, "a");
        if (nbt.contains("b")) b = read(nbt, "b");
    }

    @Override
    protected void writeNbt(NbtCompound nbt) {
        super.writeNbt(nbt);
        nbt.putString("a", Registries.BLOCK.getId(a).toString());
        nbt.putString("b", Registries.BLOCK.getId(b).toString());
    }

    @Override
    public Packet<ClientPlayPacketListener> toUpdatePacket() { return BlockEntityUpdateS2CPacket.create(this); }

    @Override
    public NbtCompound toInitialChunkDataNbt() { return createNbt(); }
}
