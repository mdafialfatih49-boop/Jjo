package com.blockfusion;

import net.minecraft.block.*;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.loot.context.LootContextParameterSet;
import net.minecraft.loot.context.LootContextParameters;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.IntProperty;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;

import java.util.List;

public class FusedBlock extends BlockWithEntity {
    public static final IntProperty LIGHT = IntProperty.of("light", 0, 15);
    public static final BooleanProperty REDSTONE = BooleanProperty.of("redstone");

    public FusedBlock(Settings settings) {
        super(settings);
        setDefaultState(getStateManager().getDefaultState().with(LIGHT, 0).with(REDSTONE, false));
    }

    @Override protected void appendProperties(StateManager.Builder<Block, BlockState> b) { b.add(LIGHT, REDSTONE); }
    @Override public net.minecraft.block.entity.BlockEntity createBlockEntity(BlockPos pos, BlockState state) { return new FusedBlockEntity(pos, state); }

    /** Hitung ulang property (cahaya, redstone) dari kedua block asal. */
    public static void refresh(World world, BlockPos pos) {
        BlockEntity be = world.getBlockEntity(pos);
        BlockState st = world.getBlockState(pos);
        if (!(be instanceof FusedBlockEntity f) || !(st.getBlock() instanceof FusedBlock)) return;
        BlockState ns = st.with(LIGHT, f.light()).with(REDSTONE, f.redstone());
        if (ns != st) world.setBlockState(pos, ns, Block.NOTIFY_ALL);
        else world.updateListeners(pos, st, st, Block.NOTIFY_ALL);
    }

    @Override
    public void onPlaced(World world, BlockPos pos, BlockState state, LivingEntity placer, ItemStack stack) {
        super.onPlaced(world, pos, state, placer, stack);
        if (!world.isClient) refresh(world, pos);
    }

    // ---- kecepatan menghancurkan = rata-rata kekerasan kedua block (bedrock = tidak bisa) ----
    @Override
    public float calcBlockBreakingDelta(BlockState state, PlayerEntity player, BlockView world, BlockPos pos) {
        BlockEntity be = world.getBlockEntity(pos);
        float h = be instanceof FusedBlockEntity f ? f.hardness(world, pos) : 3f;
        if (h < 0) return 0f;
        return player.getBlockBreakingSpeed(state) / h / 30f;
    }

    // ---- drop & pick block membawa data gabungan ----
    @Override
    public List<ItemStack> getDroppedStacks(BlockState state, LootContextParameterSet.Builder builder) {
        BlockEntity be = builder.getOptional(LootContextParameters.BLOCK_ENTITY);
        if (be instanceof FusedBlockEntity f) return List.of(FusedBlockItem.stackOf(f.getA(), f.getB()));
        return List.of(new ItemStack(this));
    }

    @Override
    public ItemStack getPickStack(BlockView world, BlockPos pos, BlockState state) {
        if (world.getBlockEntity(pos) instanceof FusedBlockEntity f) return FusedBlockItem.stackOf(f.getA(), f.getB());
        return new ItemStack(this);
    }

    // ---- redstone ----
    @Override public boolean emitsRedstonePower(BlockState state) { return state.get(REDSTONE); }
    @Override public int getWeakRedstonePower(BlockState state, BlockView world, BlockPos pos, net.minecraft.util.math.Direction dir) { return state.get(REDSTONE) ? 15 : 0; }

    // ---- efek saat diinjak / jatuh ----
    @Override
    public void onSteppedOn(World world, BlockPos pos, BlockState state, Entity entity) {
        if (world.getBlockEntity(pos) instanceof FusedBlockEntity f) {
            if (f.slows()) entity.slowMovement(state, new Vec3d(0.5, 1.0, 0.5));
            if (f.hurts() && entity instanceof LivingEntity le && !le.bypassesSteppingEffects() && !le.isFireImmune()) {
                le.damage(world.getDamageSources().hotFloor(), 1.0f);
            }
        }
        super.onSteppedOn(world, pos, state, entity);
    }

    @Override
    public void onLandedUpon(World world, BlockState state, BlockPos pos, Entity entity, float fallDistance) {
        if (world.getBlockEntity(pos) instanceof FusedBlockEntity f) {
            if (f.bouncy() && !entity.bypassesLandingEffects()) {
                entity.handleFallDamage(fallDistance, 0.0f, world.getDamageSources().fall());
                return;
            }
            if (f.cushion()) {
                entity.handleFallDamage(fallDistance, 0.2f, world.getDamageSources().fall());
                return;
            }
        }
        super.onLandedUpon(world, state, pos, entity, fallDistance);
    }

    @Override
    public void onEntityLand(BlockView world, Entity entity) {
        BlockPos below = entity.getBlockPos().down();
        if (world.getBlockEntity(below) instanceof FusedBlockEntity f && f.bouncy() && !entity.bypassesLandingEffects()) {
            Vec3d v = entity.getVelocity();
            if (v.y < 0.0) {
                double d = entity instanceof LivingEntity ? 1.0 : 0.8;
                entity.setVelocity(v.x, -v.y * d, v.z);
            }
        } else {
            super.onEntityLand(world, entity);
        }
    }

    // ---- TNT gabungan ----
    @Override
    public void onBlockAdded(BlockState state, World world, BlockPos pos, BlockState old, boolean notify) {
        if (!old.isOf(state.getBlock()) && !world.isClient && world.isReceivingRedstonePower(pos)) {
            // dinyalakan oleh redstone setelah dipasang
            world.scheduleBlockTick(pos, this, 1);
        }
    }

    @Override
    public void scheduledTick(BlockState state, net.minecraft.server.world.ServerWorld world, BlockPos pos, net.minecraft.util.math.random.Random random) {
        if (world.getBlockEntity(pos) instanceof FusedBlockEntity f && f.explosive() && world.isReceivingRedstonePower(pos)) detonate(world, pos, f);
    }

    @Override
    public void neighborUpdate(BlockState state, World world, BlockPos pos, Block source, BlockPos sourcePos, boolean notify) {
        if (!world.isClient && world.getBlockEntity(pos) instanceof FusedBlockEntity f && f.explosive() && world.isReceivingRedstonePower(pos)) {
            detonate(world, pos, f);
        }
    }

    @Override
    public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
        ItemStack st = player.getStackInHand(hand);
        if (world.getBlockEntity(pos) instanceof FusedBlockEntity f && f.explosive() && (st.isOf(Items.FLINT_AND_STEEL) || st.isOf(Items.FIRE_CHARGE))) {
            if (!world.isClient) {
                if (st.isOf(Items.FLINT_AND_STEEL)) st.damage(1, player, p -> p.sendToolBreakStatus(hand));
                else if (!player.isCreative()) st.decrement(1);
                detonate(world, pos, f);
            }
            return ActionResult.success(world.isClient);
        }
        return ActionResult.PASS;
    }

    public static void detonate(World world, BlockPos pos, FusedBlockEntity f) {
        if (world.isClient) return;
        Block other = f.transformBlock();
        float power = 4f;
        if (f.isSuper()) power = 9f;
        else if (other != null) {
            float oh = other.getDefaultState().getHardness(world, pos);
            power = 4f + Math.min(Math.max(oh, 0f), 50f) / 10f; // obsidian (50) -> ledakan 9
        }
        world.removeBlock(pos, false);
        world.createExplosion(null, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, power, World.ExplosionSourceType.TNT);
        world.playSound(null, pos, SoundEvents.ENTITY_TNT_PRIMED, SoundCategory.BLOCKS, 1f, 1f);
        if (other != null) {
            BlockState target = other.getDefaultState();
            int r = 7;
            BlockPos.Mutable m = new BlockPos.Mutable();
            for (int x = -r; x <= r; x++) for (int y = -r; y <= r; y++) for (int z = -r; z <= r; z++) {
                if (x * x + y * y + z * z > r * r) continue;
                m.set(pos.getX() + x, pos.getY() + y, pos.getZ() + z);
                BlockState s = world.getBlockState(m);
                if (s.isAir() || s.hasBlockEntity() || !s.getFluidState().isEmpty()) continue;
                if (s.getHardness(world, m) < 0) continue;
                world.setBlockState(m, target, Block.NOTIFY_ALL);
            }
        }
    }
}
