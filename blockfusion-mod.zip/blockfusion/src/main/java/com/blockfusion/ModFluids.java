package com.blockfusion;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Blocks;
import net.minecraft.block.FluidBlock;
import net.minecraft.fluid.FlowableFluid;
import net.minecraft.item.BucketItem;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public final class ModFluids {
    public static final FlowableFluid STILL = Registry.register(Registries.FLUID, ModContent.id("milk_fluid"), new MilkFluid.Still());
    public static final FlowableFluid FLOWING = Registry.register(Registries.FLUID, ModContent.id("flowing_milk_fluid"), new MilkFluid.Flowing());
    public static final FluidBlock BLOCK = Registry.register(Registries.BLOCK, ModContent.id("milk_fluid"),
            new FluidBlock(STILL, AbstractBlock.Settings.copy(Blocks.WATER)));
    public static final Item BUCKET = Registry.register(Registries.ITEM, ModContent.id("milk_fluid_bucket"),
            new BucketItem(STILL, new Item.Settings().recipeRemainder(Items.BUCKET).maxCount(1)));

    public static void init() {}
}
