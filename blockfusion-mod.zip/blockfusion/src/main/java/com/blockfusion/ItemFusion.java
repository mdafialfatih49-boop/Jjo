package com.blockfusion;

import net.minecraft.block.Block;
import net.minecraft.block.PistonBlock;
import net.minecraft.block.Blocks;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

/** Aturan fusi item. Mengembalikan {hasil, sisa} atau null jika tidak bisa. */
public final class ItemFusion {
    private ItemFusion() {}

    private static boolean pair(Item a, Item b, Item x, Item y) {
        return (a == x && b == y) || (a == y && b == x);
    }

    private static boolean isPistonItem(Item i) {
        return i instanceof BlockItem bi && bi.getBlock() instanceof PistonBlock;
    }

    public static ItemStack[] fuse(ItemStack a, ItemStack b) {
        Item ia = a.getItem(), ib = b.getItem();
        if (a.isEmpty() || b.isEmpty()) return null;

        // cairan: air + susu = susu fluid (bisa diletakkan)
        if (pair(ia, ib, Items.WATER_BUCKET, Items.MILK_BUCKET)) {
            return new ItemStack[]{new ItemStack(ModFluids.BUCKET), new ItemStack(Items.BUCKET)};
        }
        // piston + piston = super piston
        if (isPistonItem(ia) && isPistonItem(ib)) {
            boolean sticky = ((BlockItem) ia).getBlock() == Blocks.STICKY_PISTON || ((BlockItem) ib).getBlock() == Blocks.STICKY_PISTON
                    || ((BlockItem) ia).getBlock() == ModContent.SUPER_STICKY_PISTON || ((BlockItem) ib).getBlock() == ModContent.SUPER_STICKY_PISTON;
            return new ItemStack[]{new ItemStack(sticky ? ModContent.SUPER_STICKY_PISTON_ITEM : ModContent.SUPER_PISTON_ITEM), ItemStack.EMPTY};
        }
        if (ia instanceof FusedItem || ib instanceof FusedItem) return null;
        // block + block = block gabungan
        if (ia instanceof BlockItem ba && ib instanceof BlockItem bb
                && FusionHandler.fusableBlock(ba.getBlock()) && FusionHandler.fusableBlock(bb.getBlock())) {
            return new ItemStack[]{FusedBlockItem.stackOf(ba.getBlock(), bb.getBlock()), ItemStack.EMPTY};
        }
        // item apa pun + item apa pun = item gabungan
        return new ItemStack[]{FusedItem.stackOf(a, b), ItemStack.EMPTY};
    }
}
