package com.blockfusion;

public final class PistonFlags {
    public static final ThreadLocal<Boolean> SUPER = ThreadLocal.withInitial(() -> Boolean.FALSE);
    private PistonFlags() {}
}
