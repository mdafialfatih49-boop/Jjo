package com.blockfusion;

import net.minecraft.block.BlockState;
import net.minecraft.block.FluidBlock;
import net.minecraft.fluid.FlowableFluid;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.FluidState;
import net.minecraft.item.Item;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.BlockView;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;
import net.minecraft.world.World;

public abstract class MilkFluid extends FlowableFluid {
    @Override public Fluid getFlowing() { return ModFluids.FLOWING; }
    @Override public Fluid getStill() { return ModFluids.STILL; }
    @Override protected boolean isInfinite(World world) { return false; }
    @Override protected void beforeBreakingBlock(WorldAccess world, BlockPos pos, BlockState state) {
        net.minecraft.block.entity.BlockEntity be = state.hasBlockEntity() ? world.getBlockEntity(pos) : null;
        net.minecraft.block.Block.dropStacks(state, world, pos, be);
    }
    @Override protected int getFlowSpeed(WorldView world) { return 4; }
    @Override protected int getLevelDecreasePerBlock(WorldView world) { return 1; }
    @Override public Item getBucketItem() { return ModFluids.BUCKET; }
    @Override protected boolean canBeReplacedWith(FluidState state, BlockView world, BlockPos pos, Fluid fluid, Direction direction) { return false; }
    @Override public int getTickRate(WorldView world) { return 5; }
    @Override protected float getBlastResistance() { return 100.0f; }
    @Override protected BlockState toBlockState(FluidState state) {
        return ModFluids.BLOCK.getDefaultState().with(Properties.LEVEL_15, getBlockStateLevel(state));
    }

    public static class Flowing extends MilkFluid {
        @Override protected void appendProperties(StateManager.Builder<Fluid, FluidState> builder) {
            super.appendProperties(builder);
            builder.add(LEVEL);
        }
        @Override public int getLevel(FluidState state) { return state.get(LEVEL); }
        @Override public boolean isStill(FluidState state) { return false; }
    }

    public static class Still extends MilkFluid {
        @Override public int getLevel(FluidState state) { return 8; }
        @Override public boolean isStill(FluidState state) { return true; }
    }
}
