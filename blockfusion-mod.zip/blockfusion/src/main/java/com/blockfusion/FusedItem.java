package com.blockfusion;

import com.google.common.collect.Multimap;
import com.mojang.datafixers.util.Pair;
import net.minecraft.block.BlockState;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.FoodComponent;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.UseAction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/** Item gabungan: menyimpan dua item. Serangan, kecepatan menambang, dan makanan digabung otomatis. */
public class FusedItem extends Item {
    private static final UUID ATTACK_DAMAGE_ID = UUID.fromString("CB3F55D3-645C-4F38-A497-9C13A33DB5CF");
    private static final UUID ATTACK_SPEED_ID = UUID.fromString("FA233E1C-4180-4865-B01B-BCCE9785ACA3");

    public FusedItem(Settings settings) { super(settings.maxCount(1)); }

    public static ItemStack stackOf(ItemStack a, ItemStack b) {
        ItemStack s = new ItemStack(ModContent.FUSED_ITEM);
        ItemStack ca = a.copy(); ca.setCount(1);
        ItemStack cb = b.copy(); cb.setCount(1);
        NbtCompound t = s.getOrCreateNbt();
        t.put("A", ca.writeNbt(new NbtCompound()));
        t.put("B", cb.writeNbt(new NbtCompound()));
        applyModifiers(s, ca, cb);
        return s;
    }

    public static ItemStack[] stacksOf(ItemStack stack) {
        NbtCompound t = stack.getNbt();
        if (t == null) return new ItemStack[]{ItemStack.EMPTY, ItemStack.EMPTY};
        return new ItemStack[]{ItemStack.fromNbt(t.getCompound("A")), ItemStack.fromNbt(t.getCompound("B"))};
    }

    private static void store(ItemStack stack, ItemStack[] s) {
        NbtCompound t = stack.getOrCreateNbt();
        t.put("A", s[0].writeNbt(new NbtCompound()));
        t.put("B", s[1].writeNbt(new NbtCompound()));
    }

    private static void applyModifiers(ItemStack fused, ItemStack a, ItemStack b) {
        Map<EntityAttribute, Double> sum = new LinkedHashMap<>();
        for (ItemStack s : new ItemStack[]{a, b}) {
            Multimap<EntityAttribute, EntityAttributeModifier> mm = s.getAttributeModifiers(EquipmentSlot.MAINHAND);
            for (Map.Entry<EntityAttribute, EntityAttributeModifier> e : mm.entries()) {
                if (e.getValue().getOperation() != EntityAttributeModifier.Operation.ADDITION) continue;
                EntityAttribute at = e.getKey();
                double v = e.getValue().getValue();
                if (sum.containsKey(at)) {
                    if (at == EntityAttributes.GENERIC_ATTACK_SPEED) sum.put(at, Math.max(sum.get(at), v));
                    else sum.put(at, sum.get(at) + v);
                } else sum.put(at, v);
            }
        }
        for (Map.Entry<EntityAttribute, Double> e : sum.entrySet()) {
            UUID id = e.getKey() == EntityAttributes.GENERIC_ATTACK_DAMAGE ? ATTACK_DAMAGE_ID
                    : e.getKey() == EntityAttributes.GENERIC_ATTACK_SPEED ? ATTACK_SPEED_ID
                    : UUID.nameUUIDFromBytes(e.getKey().getTranslationKey().getBytes());
            fused.addAttributeModifier(e.getKey(), new EntityAttributeModifier(id, "Fused modifier", e.getValue(), EntityAttributeModifier.Operation.ADDITION), EquipmentSlot.MAINHAND);
        }
    }

    @Override
    public Text getName(ItemStack stack) {
        ItemStack[] s = stacksOf(stack);
        if (s[0].isEmpty() && s[1].isEmpty()) return super.getName(stack);
        if (s[0].isOf(s[1].getItem())) return Text.translatable("item.blockfusion.fused_item_super", s[0].getName());
        return Text.translatable("item.blockfusion.fused_item", s[0].getName(), s[1].getName());
    }

    // ---- menambang ----
    @Override
    public float getMiningSpeedMultiplier(ItemStack stack, BlockState state) {
        float f = 1.0f;
        for (ItemStack s : stacksOf(stack)) if (!s.isEmpty()) f = Math.max(f, s.getMiningSpeedMultiplier(state));
        return f;
    }

    @Override
    public boolean isSuitableFor(BlockState state) {
        return false;
    }

    @Override
    public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        ItemStack[] s = stacksOf(stack);
        for (ItemStack x : s) if (!x.isEmpty()) x.getItem().postHit(x, target, attacker);
        store(stack, s);
        return true;
    }

    @Override
    public boolean postMine(ItemStack stack, World world, BlockState state, BlockPos pos, LivingEntity miner) {
        ItemStack[] s = stacksOf(stack);
        for (ItemStack x : s) if (!x.isEmpty()) x.getItem().postMine(x, world, state, pos, miner);
        store(stack, s);
        return true;
    }

    // ---- makanan ----
    private static boolean hasFood(ItemStack stack) {
        for (ItemStack s : stacksOf(stack)) if (!s.isEmpty() && s.getItem().isFood()) return true;
        return false;
    }

    @Override public UseAction getUseAction(ItemStack stack) { return hasFood(stack) ? UseAction.EAT : UseAction.NONE; }
    @Override public int getMaxUseTime(ItemStack stack) { return hasFood(stack) ? 32 : 0; }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack s = player.getStackInHand(hand);
        if (hasFood(s) && player.canConsume(false)) {
            player.setCurrentHand(hand);
            return TypedActionResult.consume(s);
        }
        return TypedActionResult.pass(s);
    }

    @Override
    public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
        if (!world.isClient && user instanceof PlayerEntity p) {
            for (ItemStack x : stacksOf(stack)) {
                FoodComponent fc = x.isEmpty() ? null : x.getItem().getFoodComponent();
                if (fc == null) continue;
                p.getHungerManager().add(fc.getHunger(), fc.getSaturationModifier());
                for (Pair<StatusEffectInstance, Float> pr : fc.getStatusEffects()) {
                    if (pr.getFirst() != null && world.random.nextFloat() < pr.getSecond()) {
                        user.addStatusEffect(new StatusEffectInstance(pr.getFirst()));
                    }
                }
            }
        }
        world.playSound(null, user.getX(), user.getY(), user.getZ(), SoundEvents.ENTITY_GENERIC_EAT, SoundCategory.NEUTRAL, 1f, 1f);
        if (!(user instanceof PlayerEntity pl) || !pl.getAbilities().creativeMode) stack.decrement(1);
        return stack;
    }
}
